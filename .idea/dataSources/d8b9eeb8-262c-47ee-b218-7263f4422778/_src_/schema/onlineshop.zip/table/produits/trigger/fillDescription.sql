CREATE TRIGGER `fillDescription`
BEFORE INSERT ON `produits`
FOR EACH ROW
  SET NEW.description = 'lobortis nisl ut aliquip '