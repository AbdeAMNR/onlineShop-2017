CREATE TRIGGER `toUpperVeh`
BEFORE INSERT ON `vehicle`
FOR EACH ROW
  BEGIN
    SET new.cin = upper(new.cin);
    SET new.numMatric = upper(new.numMatric);
  END