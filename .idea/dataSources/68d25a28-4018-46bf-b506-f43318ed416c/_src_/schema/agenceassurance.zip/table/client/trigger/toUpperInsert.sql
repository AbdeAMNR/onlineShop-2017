CREATE TRIGGER `toUpperInsert`
BEFORE INSERT ON `client`
FOR EACH ROW
  BEGIN
    SET new.nomComplet = upper(new.nomComplet);
    SET new.cin = upper(new.cin);
  END