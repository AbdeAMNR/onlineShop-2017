CREATE TRIGGER `fillDescription`
BEFORE INSERT ON `produits`
FOR EACH ROW
  SET NEW.description = 'lobortis nisl ut aliquip ex ea commodo consequat.lobortis nisl ut aliquip ex ea commodo consequat.'