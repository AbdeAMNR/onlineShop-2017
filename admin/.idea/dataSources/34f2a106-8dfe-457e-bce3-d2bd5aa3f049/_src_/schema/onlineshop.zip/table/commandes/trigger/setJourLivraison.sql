CREATE TRIGGER `setJourLivraison`
BEFORE INSERT ON `commandes`
FOR EACH ROW
  BEGIN
    DECLARE livDate DATE;
    DECLARE newDate DATE;
    SET livDate = curdate();
    SET newDate = DATE_ADD(now(), INTERVAL 7 DAY);
    SET NEW.dateCommande = livDate;
    SET NEW.DateLivraisonPrevue = newDate;
  END