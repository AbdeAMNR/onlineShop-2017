CREATE TRIGGER `upperName`
BEFORE INSERT ON `client`
FOR EACH ROW
  BEGIN
    SET NEW.nom_Prenom = upper(NEW.nom_Prenom);
  END