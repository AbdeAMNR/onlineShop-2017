CREATE TRIGGER `cltCascade`
AFTER DELETE ON `client`
FOR EACH ROW
  BEGIN
    DELETE FROM Vehicle
    WHERE cin = old.cin;
  END