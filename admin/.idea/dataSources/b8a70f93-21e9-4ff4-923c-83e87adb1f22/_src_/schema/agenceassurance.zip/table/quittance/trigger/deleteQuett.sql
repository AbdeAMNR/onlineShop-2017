CREATE TRIGGER `deleteQuett`
AFTER DELETE ON `quittance`
FOR EACH ROW
  BEGIN
    DELETE FROM Fractionnement
    WHERE numQuitt = old.numQuitt;
    DELETE FROM Credit
    WHERE numQuitt = old.numQuitt;
  END